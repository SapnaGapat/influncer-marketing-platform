// import "./App.css";
// import Home from "./Home";
// import { BrowserRouter, Route, Routes } from "react-router-dom";
// import BrandIntro from "./components/Brand/BrandIntro";
// import InfluencerIntro from "./components/Influencer/InfluencerIntro";
// import BrandSignUp from "./components/Brand/BrandSignUp";
// import InfluencerSignUp from "./components/Influencer/InfluencerSignUp";
// import ManagerSignUp from "./components/manager/ManagerSignUp";
// import AboutUs from "./components/About";
// import NewToSite from "./components/Newtosite";
// import BrandHome from "./components/Brand/BrandHome";
// import BrandPendingRequest from "./components/Brand/BrandPendingRequest";
// import BrandArrivalRequest from "./components/Brand/BrandArrivalRequest";
// import BrandConsignments from "./components/Brand/BrandConsignments";
// import BrandHistory from "./components/Brand/BrandHistory";
// import BrandLogin from "./components/Brand/BrandLogin";
// import BrandDetails from "./components/Influencer/BrandDetails";
// import BrandProfile from "./components/Brand/BrandProfile.jsx";
// import BrandProfileEdit from "./components/Brand/BrandProfileEdit.jsx";

// import InfluencerDetails from "./components/Brand/InfluencerDetails";
// import InfluencerHome from "./components/Influencer/InfluencerHome";
// import InfluencerProfile from "./components/Influencer/InfluencerProfile";
// import InfluencerProfileEdit from "./components/Influencer/InfluencerProfileEdit";
// import InfluencerConsignments from "./components/Influencer/InfluencerConsignments";
// import InfluencerHistory from "./components/Influencer/InfluencerHistory";
// import InfluencerLogin from "./components/Influencer/InfluencerLogin";
// import InfluencerArrivalRequest from "./components/Influencer/InfluencerArrivalRequest";
// import InfluencerPendingRequest from "./components/Influencer/InfluencerPendingRequest";

// import ManagerHome from './components/manager/ManagerHome';
// import ManagerLogin from './components/manager/ManagerLogin';
// import ManagerHeader from './components/manager/ManagerHeader';
// import AddNewInfluencer from './components/manager/AddNewInfluencer';
// import AddNewBrand from './components/manager/AddNewBrand';
// import ManagerProfile from './components/manager/ManagerProfile';


// const App = () => {
//   return (
//     <BrowserRouter>
//       <Routes>
//         <Route path="/" element={<Home />} />
//         <Route path="/BrandIntro" element={<BrandIntro />} />
//         <Route path="/InfluencerIntro" element={<InfluencerIntro />} />
//         <Route path="/BrandSignUp" element={<BrandSignUp />} />
//         <Route path="/InfluencerSignUp" element={<InfluencerSignUp />} />
//         <Route path="/ManagerSignUp" element={<ManagerSignUp />} />
//         <Route path="/BrandLogin" element={<BrandLogin />} />
//         <Route path="/InfluencerLogin" element={<InfluencerLogin />} />
//         <Route path="/AboutUs" element={<AboutUs />} />
//         <Route path="NewToSite" element={<NewToSite />} />

//         <Route path="/BrandHome" element={<BrandHome />} />
//         <Route path="/BrandPendingRequest" element={<BrandPendingRequest />} />
//         <Route path="/BrandArrivalRequest" element={<BrandArrivalRequest />} />
//         <Route path="/BrandConsignments" element={<BrandConsignments />} />
//         <Route path="/BrandDetails" element={<BrandDetails />} />
//         <Route path="/BrandProfile" element={<BrandProfile />} />
//         <Route path="/BrandProfileEdit" element={<BrandProfileEdit />} />

//         <Route path="/BrandHistory" element={<BrandHistory />} />
//         <Route path="/InfluencerDetails" element={<InfluencerDetails />} />

//         <Route path="/InfluencerHome" element={<InfluencerHome />} />
//         <Route path="/InfluencerArrivalRequest" element={<InfluencerArrivalRequest />} />
//         <Route path="/InfluencerProfile" element={<InfluencerProfile />} />
//         <Route
//           path="/InfluencerProfileEdit"
//           element={<InfluencerProfileEdit />}
//         />
//         <Route
//           path="/InfluencerConsignments"
//           element={<InfluencerConsignments />}
//         />

//         <Route path="/InfluencerHistory" element={<InfluencerHistory />} />
//         <Route path="/InfluencerPendingRequest" element={<InfluencerPendingRequest />} />

//         <Route path="/ManagerHome" element={<ManagerHome />} />
//         <Route path="/ManagerLogin" element={<ManagerLogin />} />
//         <Route path="/ManagerHeader" element={<ManagerHeader />} />
//         <Route path="/AddNewInfluencer" element={<AddNewInfluencer />} />
//         <Route path="/AddNewBrand" element={<AddNewBrand />} />
//         <Route path="/ManagerProfile" element={<ManagerProfile />} />

//       </Routes>
//     </BrowserRouter>
//   );
// };

// export default App;




import "./App.css";
import Home from "./Home";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import BrandIntro from "./components/Brand/BrandIntro";
import InfluencerIntro from "./components/Influencer/InfluencerIntro";
import BrandSignUp from "./components/Brand/BrandSignUp";
import InfluencerSignUp from "./components/Influencer/InfluencerSignUp";
import ManagerSignUp from "./components/manager/ManagerSignUp";
import AboutUs from "./components/About";
import NewToSite from "./components/Newtosite";
import BrandHome from "./components/Brand/BrandHome";
import BrandPendingRequest from "./components/Brand/BrandPendingRequest";
import BrandArrivalRequest from "./components/Brand/BrandArrivalRequest";
import BrandConsignments from "./components/Brand/BrandConsignments";
import BrandHistory from "./components/Brand/BrandHistory";
import BrandLogin from "./components/Brand/BrandLogin";
import BrandDetails from "./components/Influencer/BrandDetails";
import BrandProfile from "./components/Brand/BrandProfile.jsx";
import BrandProfileEdit from "./components/Brand/BrandProfileEdit.jsx";
import InfluencerDetails from "./components/Brand/InfluencerDetails";
import InfluencerHome from "./components/Influencer/InfluencerHome";
import InfluencerProfile from "./components/Influencer/InfluencerProfile";
import InfluencerProfileEdit from "./components/Influencer/InfluencerProfileEdit";
import InfluencerConsignments from "./components/Influencer/InfluencerConsignments";
import InfluencerHistory from "./components/Influencer/InfluencerHistory";
import InfluencerLogin from "./components/Influencer/InfluencerLogin";
import InfluencerArrivalRequest from "./components/Influencer/InfluencerArrivalRequest";
import InfluencerPendingRequest from "./components/Influencer/InfluencerPendingRequest";
import InfluencerCompare from "./components/Brand/InfluencerCompare"; 
import Influencerconsolidation from './components/Brand/Influencerconsolidation';
import ManagerHome from './components/manager/ManagerHome';
import ManagerLogin from './components/manager/ManagerLogin';
import ManagerHeader from './components/manager/ManagerHeader';
import AddNewInfluencer from './components/manager/AddNewInfluencer';
import AddNewBrand from './components/manager/AddNewBrand';
import ManagerProfile from './components/manager/ManagerProfile';

// Import the CreateCampaign component
import CreateCampaign from "./components/Brand/CreateCampaign";

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/BrandIntro" element={<BrandIntro />} />
        <Route path="/InfluencerIntro" element={<InfluencerIntro />} />
        <Route path="/BrandSignUp" element={<BrandSignUp />} />
        <Route path="/InfluencerSignUp" element={<InfluencerSignUp />} />
        <Route path="/ManagerSignUp" element={<ManagerSignUp />} />
        <Route path="/BrandLogin" element={<BrandLogin />} />
        <Route path="/InfluencerLogin" element={<InfluencerLogin />} />
        <Route path="/AboutUs" element={<AboutUs />} />
        <Route path="/NewToSite" element={<NewToSite />} />
        <Route path="/BrandHome" element={<BrandHome />} />
        <Route path="/BrandPendingRequest" element={<BrandPendingRequest />} />
        <Route path="/BrandArrivalRequest" element={<BrandArrivalRequest />} />
        <Route path="/BrandConsignments" element={<BrandConsignments />} />
        <Route path="/BrandDetails" element={<BrandDetails />} />
        <Route path="/BrandProfile" element={<BrandProfile />} />
        <Route path="/BrandProfileEdit" element={<BrandProfileEdit />} />
        <Route path="/BrandHistory" element={<BrandHistory />} />
        <Route path="/InfluencerDetails" element={<InfluencerDetails />} />
        <Route path="/InfluencerHome" element={<InfluencerHome />} />
        <Route path="/InfluencerArrivalRequest" element={<InfluencerArrivalRequest />} />
        <Route path="/InfluencerProfile" element={<InfluencerProfile />} />
        <Route path="/InfluencerProfileEdit" element={<InfluencerProfileEdit />} />
        <Route path="/InfluencerConsignments" element={<InfluencerConsignments />} />
        <Route path="/InfluencerHistory" element={<InfluencerHistory />} />
        <Route path="/InfluencerPendingRequest" element={<InfluencerPendingRequest />} />
        <Route path="/compare" element={<InfluencerCompare />} />
        <Route path="/consolidation" element={<Influencerconsolidation />} />
        <Route path="/ManagerHome" element={<ManagerHome />} />
        <Route path="/ManagerLogin" element={<ManagerLogin />} />
        <Route path="/ManagerHeader" element={<ManagerHeader />} />
        <Route path="/AddNewInfluencer" element={<AddNewInfluencer />} />
        <Route path="/AddNewBrand" element={<AddNewBrand />} />
        <Route path="/ManagerProfile" element={<ManagerProfile />} />

        {/* Add the route for the CreateCampaign component */}
        <Route path="/create" element={<CreateCampaign />} />
      </Routes>
    </BrowserRouter>
  );
};

export default App;
